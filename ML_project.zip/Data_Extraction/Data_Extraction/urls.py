"""
URL configuration for Data_Extraction project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from Govt_certificates import views


urlpatterns = [
    path('api/',include('Govt_certificates.urls')),
    path("api/add_user", views.user_details, name="add_user"),
    path('api/login_user', views.login_user, name='login_user'),
    path('send_email_view', views.send_email_view, name='send_email_view')

    # path("",views.home,name="home"),
    # path('admin/', admin.site.urls),
    # path('upload/', views.upload_pdf, name='upload_pdf'),
    # path('studentApplicationPdf/', views.studentApplicationPdf, name='studentApplicationPdf'),
    # path('table_data_extract/', views.table_data_extract, name='table_data_extract'),
    # path('pdf_image_converter/', views.pdf_image_converter, name='pdf_image_converter'),
    # path('pdf_editor/', views.pdf_editor, name='pdf_editor'),
    # path('face_comparison/', views.face_comparison, name='face_comparison'),
    # path('api/student_application_pdf_api/',views.student_application_pdf_api, name='student_application_pdf_api')
    # path('api/upload-pdf/', views.upload_pdf_api, name='upload_pdf_api'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
