from django.contrib.auth.hashers import make_password, check_password
from django.db import models

# Create your models here.
from django.db import models
from django.utils import timezone


class Students(models.Model):
    first_name= models.CharField(max_length=100)
    last_name= models.CharField(max_length=100)
    dob = models.DateField()
    phone = models.CharField(max_length=10)
    email= models.EmailField(unique=True)
    address = models.TextField()
    gender = models.CharField(max_length=1)
    # profile = models.TextField()

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class UserDetails(models.Model):
    username = models.EmailField(unique=True)
    password = models.CharField(max_length=120)
    phone = models.CharField(max_length=10)
    created = models.DateTimeField(default=timezone.now)
    token = models.TextField(null=True)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return f"{self.username}"
