# # Input CSV data as a string
# import csv
#
# csv_data = """
# SUBJECT,U.E. Marks Max.,U.E. Marks Secured,I.A.J Sess. Marks Max.,I.A.J Sess. Marks Secured,Total Marks Max.,Total Marks Secured,Result
# COMMUNICATIVE ENGLISH,100,66,50,28,150,94,PASS
# MATHEMATICS - I,100,63,50,26,150,89,PASS
# APPLIED PHYSICS,100,72,50,29,150,101,PASS
# ENGINEERING CHEMISTRY,100,71,50,30,150,101,PASS
# ENGINEERING MECHANICS,100,61,50,33,150,94,PASS
# PROGRAMMING CONCEPTS & INFORMATION TECH,100,58,50,28,150,86,PASS
# ENGINEERING GRAPHICS,100,69,50,30,150,99,PASS
# WORK SHOP PRACTICE LAB,50,32,25,15,75,47,PASS
# APPLIED PHYSICS LAB,50,30,25,18,75,48,PASS
# ENGINEERING CHEMISTRY LAB,50,29,25,20,75,49,PASS
# COMPUTER PROGRAMMING LAB,50,33,25,16,75,49,PASS
# ENVIRONMENTAL STUDIES *,50,31,50,20,100,51,PASS
# """
#
# # Split the CSV data into lines
# lines = csv_data.strip().split('\n')
#
# # Initialize an empty list to store all the rows
# rows = []
#
# # Iterate over each line in the CSV data
# for line in lines:
#     # Split each line by commas and store it as a list of values
#     row = line.split(',')
#     # Push the row into the rows list
#     rows.append(row)
#
# filename = 'marks_report.csv'
#
# # Writing to CSV
# with open(filename, mode='w', newline='') as file:
#     writer = csv.writer(file)
#     writer.writerows(rows)
import re

data = '''Sure, here is the extracted data from the image in CSV format:

```csv
SUBJECT,U.E. Marks Max.,U.E. Marks Secured,I.A.J Sess. Marks Max.,I.A.J Sess. Marks Secured,Total Marks Max.,Total Marks Secured,Result
COMMUNICATIVE ENGLISH,100,66,50,28,150,94,PASS
MATHEMATICS - I,100,63,50,26,150,89,PASS
APPLIED PHYSICS,100,72,50,29,150,101,PASS
ENGINEERING CHEMISTRY,100,71,50,30,150,101,PASS
ENGINEERING MECHANICS,100,61,50,33,150,94,PASS
PROGRAMMING CONCEPTS & INFORMATION TECH,100,58,50,28,150,86,PASS
ENGINEERING GRAPHICS,100,69,50,30,150,99,PASS
WORK SHOP PRACTICE LAB,50,32,25,15,75,47,PASS
APPLIED PHYSICS LAB,50,30,25,18,75,48,PASS
ENGINEERING CHEMISTRY LAB,50,29,25,20,75,49,PASS
COMPUTER PROGRAMMING LAB,50,33,25,16,75,49,PASS
ENVIRONMENTAL STUDIES *,50,31,50,20,100,51,PASS
GRAND TOTAL,850,,,,1350,957,PASS
```

Note: The asterisk (*) in "ENVIRONMENTAL STUDIES *" is included as it appears in the image. The "GRAND TOTAL" row is also included as it appears in the image'''
pattern = r"```csv\n([\s\S]*?)```"
match =re.search(pattern, data)
print(match.group(1))