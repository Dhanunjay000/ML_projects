import csv
import json
import re
import zipfile
from io import BytesIO

import requests
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.mail import send_mail
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
import os
# from mistralai import Mistral
# import easyocr
import cv2
from exceptiongroup import catch
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view
# import face_recognition
# from pdf2image import convert_from_path
# from deepface import DeepFace


# api_key = "BFLJ0ssL6ghhvwicLsZtDVq9wsCx4HDq"
# client = Mistral(api_key=api_key)
# save_folder = 'path_to_save_images/'
#
# # Make sure the folder exists
# if not os.path.exists(save_folder):
#     os.makedirs(save_folder)
#
# def home(request):
#     return render(request,"home.html")
#
# def studentApplicationPdf(request):
#     if request.method == "POST" and request.FILES["pdf_file"] and request.FILES['Upload_excel_file']:
#         application_pdf = request.FILES["pdf_file"]
#         excel_file=request.FILES["Upload_excel_file"]
#         fs = FileSystemStorage()
#         application_filename = fs.save(application_pdf.name, application_pdf)
#         excel_filename = fs.save(excel_file.name, excel_file)
#         application_file_path = fs.url(application_filename)
#         excel_filepath=fs.url(excel_filename)
#         application_fullpath = fs.path(application_filename)
#         excel_fullpath= fs.path(excel_filename)
#         url = "http://ec2-3-90-54-94.compute-1.amazonaws.com:7000/api/student_application_pdf_api/"
#         # Open the files in binary mode
#         files = {
#             'pdf_file': ('your_pdf.pdf', open(application_fullpath, 'rb')),
#             'Upload_excel_file': ('your_excel.xlsx', open(excel_fullpath, 'rb'))
#         }
#         timeout_duration = 20
#         try:
#             response = requests.post(url, files=files, timeout=timeout_duration)
#             response.raise_for_status()  # Raise an error for bad responses
#             extracted_text = response.json()  # Extract JSON from the response
#         except requests.Timeout:
#             extracted_text = {"error": "The request timed out."}
#         # application_pdf = client.files.upload(
#         #     file={
#         #         "file_name": application_filename,
#         #         "content": open(application_fullpath, "rb"),
#         #     },
#         #     purpose="ocr"
#         # )
#         # excel_pdf = client.files.upload(
#         #     file={
#         #         "file_name": application_filename,
#         #         "content": open(excel_fullpath, "rb"),
#         #     },
#         #     purpose="ocr"
#         # )
#         #
#         # # Retrieve the signed URL for the file
#         # signed_url1 = client.files.get_signed_url(file_id=application_pdf.id)
#         # signed_url2 = client.files.get_signed_url(file_id=excel_pdf.id)
#         # document_url = str(signed_url1.url)
#         # excel_url = str(signed_url2.url)
#         # # Define the model to use
#         # model = "mistral-small-latest"
#         #
#         # # Define the message with user query and the document URL
#         # messages = [
#         #     {
#         #         "role": "user",
#         #         "content": [
#         #             {
#         #                 "type": "text",
#         #                  "text": ''' Extract the data from the provided application form and return the result as a JSON object. The JSON should consist of key-value pairs where the keys are the respective database fields mapped to the form fields in the Excel file. Ensure that checkbox fields are identified correctly '''
#         #             },
#         #             {
#         #                 "type": "document_url",
#         #                 "document_url": document_url  # Use the URL from the upload response
#         #             },
#         #             {
#         #                 "type": "document_url",
#         #                 "document_url": excel_url  # Use the URL from the upload response
#         #             }
#         #         ]
#         #     }
#         # ]
#         # chat_response = client.chat.complete(
#         #     model=model,
#         #     messages=messages
#         # )
#         # extracted_text = chat_response.choices[0].message.content
#         # json_data = re.search(r'\{.*\}', extracted_text, re.DOTALL)
#         #
#         # if json_data:
#         #     extracted_json = json_data.group(0)
#         #     data = json.loads(extracted_json)
#         #     extracted_text =json.dumps(data, indent=4)
#         return render(request, "studentApplicationPdf.html", context={'extracted_text': extracted_text})
#     return render(request, "studentApplicationPdf.html")
#
# @api_view(['POST'])
# def student_application_pdf_api(request):
#     if request.method == "POST" and request.FILES["pdf_file"] and request.FILES['Upload_excel_file']:
#         application_pdf = request.FILES["pdf_file"]
#         excel_file=request.FILES["Upload_excel_file"]
#         fs = FileSystemStorage()
#         application_filename = fs.save(application_pdf.name, application_pdf)
#         excel_filename = fs.save(excel_file.name, excel_file)
#         application_file_path = fs.url(application_filename)
#         excel_filepath=fs.url(excel_filename)
#         application_fullpath = fs.path(application_filename)
#         excel_fullpath= fs.path(excel_filename)
#         application_pdf = client.files.upload(
#             file={
#                 "file_name": application_filename,
#                 "content": open(application_fullpath, "rb"),
#             },
#             purpose="ocr"
#         )
#         excel_pdf = client.files.upload(
#             file={
#                 "file_name": application_filename,
#                 "content": open(excel_fullpath, "rb"),
#             },
#             purpose="ocr"
#         )
#
#         # Retrieve the signed URL for the file
#         signed_url1 = client.files.get_signed_url(file_id=application_pdf.id)
#         signed_url2 = client.files.get_signed_url(file_id=excel_pdf.id)
#         document_url = str(signed_url1.url)
#         excel_url = str(signed_url2.url)
#         # Define the model to use
#         model = "mistral-small-latest"
#
#         # Define the message with user query and the document URL
#         messages = [
#             {
#                 "role": "user",
#                 "content": [
#                     {
#                         "type": "text",
#                          "text": ''' Extract the data from the provided application form and return the result as a JSON object. The JSON should consist of key-value pairs where the keys are the respective database fields mapped to the form fields in the Excel file. Ensure that checkbox fields are identified correctly '''
#                     },
#                     {
#                         "type": "document_url",
#                         "document_url": document_url  # Use the URL from the upload response
#                     },
#                     {
#                         "type": "document_url",
#                         "document_url": excel_url  # Use the URL from the upload response
#                     }
#                 ]
#             }
#         ]
#         chat_response = client.chat.complete(
#             model=model,
#             messages=messages
#         )
#         extracted_text = chat_response.choices[0].message.content
#         json_data = re.search(r'\{.*\}', extracted_text, re.DOTALL)
#
#         if json_data:
#             extracted_json = json_data.group(0)
#             data = json.loads(extracted_json)
#             return JsonResponse(data, status=200, json_dumps_params={'indent': 4})
#         else:
#             # Handle the case where no JSON is found
#             return Response({"error": "No JSON data found"}, status=status.HTTP_400_BAD_REQUEST)
#
#
#
# def upload_pdf(request):
#     if request.method == "POST" and request.FILES["pdf_file"]:
#         uploaded_file = request.FILES["pdf_file"]
#         fs = FileSystemStorage()
#         filename = fs.save(uploaded_file.name, uploaded_file)
#         file_path = fs.url(filename)
#         full_path = fs.path(filename)
#         reader = easyocr.Reader(['te', 'en'])
#         value = ''
#         images = convert_from_path(full_path)
#         image_paths = []
#         for i, image in enumerate(images):
#             image_path = os.path.join(save_folder, f'page_{i + 1}.png')
#             image.save(image_path, 'PNG')
#             image_paths.append(image_path)
#         for image_path in image_paths:
#             results = reader.readtext(image_path, detail=0)
#             for result in results:
#                 value += result
#                 value += ' '
#         extracted_text = value
#         uploaded_pdf = client.files.upload(
#             file={
#                 "file_name": uploaded_file.name,
#                 "content": open(full_path, "rb"),
#             },
#             purpose="ocr"
#         )
#
#         # Retrieve the signed URL for the file
#         signed_url = client.files.get_signed_url(file_id=uploaded_pdf.id)
#         document_url = str(signed_url.url)
#
#         # Define the model to use
#         model = "mistral-small-latest"
#
#         # Define the message with user query and the document URL
#         messages = [
#             {
#                 "role": "user",
#                 "content": [
#                     {
#                         "type": "text",
#                          "text": '''Extract the text from image and consider given text extracted from ocr now make the meaningful key-value pairs to a valid json .Extracted text from EasyOCR: {}'''.format(extracted_text)
#                     },
#                     {
#                         "type": "document_url",
#                         "document_url": document_url  # Use the URL from the upload response
#                     }
#                 ]
#             }
#         ]
#         chat_response = client.chat.complete(
#             model=model,
#             messages=messages
#         )
#         extracted_text = chat_response.choices[0].message.content
#         return render(request, "upload_pdf.html", context={'extracted_text': extracted_text})
#
#     return render(request, "upload_pdf.html")
#
#
#
# def pdf_image_converter(request):
#     if request.method == 'POST' and request.FILES['pdf_file']:
#         pdf_file = request.FILES['pdf_file']
#         if pdf_file.name.lower().endswith(".pdf"):
#             fs = FileSystemStorage()
#             filename = fs.save(pdf_file.name, pdf_file)
#             filepath = fs.path(filename)
#             images = convert_from_path(filepath, dpi=300)
#             image_paths = []
#             for i, image in enumerate(images):
#                 image_path = f'media/{filename}_page_{i + 1}.png'
#                 image.save(image_path, 'PNG')
#                 image_paths.append(image_path)
#             if len(image_paths) == 0:
#                 return render(request, 'pdf_editor.html')
#             if len(image_paths) == 1:
#                 with open(image_paths[0], 'rb') as image_file:
#                     response = HttpResponse(image_file.read(), content_type='image/png')
#                     response['Content-Disposition'] = f'attachment; filename="{filename}.png"'
#                     return response
#             else:
#                 zip_buffer = BytesIO()
#                 with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
#                     for image_path in image_paths:
#                         zip_file.write(image_path, os.path.basename(image_path))
#                 zip_buffer.seek(0)
#                 response = HttpResponse(zip_buffer, content_type='application/zip')
#                 response['Content-Disposition'] = f'attachment; filename="{filename}_converted.zip"'
#                 return response
#     return render(request, "pdf_image_converter.html")
#
# def pdf_editor(request):
#     return render(request,"pdf_editor.html")

# def table_data_extract(request):
#     if request.method=='POST' and request.FILES["pdf_file"]:
#         image_data=request.FILES["pdf_file"]
#         filename=image_data.name
#         if filename.lower().endswith(".png"):
#             fs=FileSystemStorage()
#             pdf_file_name=  fs.save(filename,image_data)
#             pdf_file_path= fs.path(pdf_file_name)
#             uploded_pdf = client.files.upload(
#                 file={
#                     "file_name": pdf_file_name,
#                     "content": open(pdf_file_path, "rb"),
#                 },
#                 purpose="ocr"
#             )
#             signed_url = client.files.get_signed_url(file_id=uploded_pdf.id)
#             document_url = str(signed_url.url)
#             # Define the model to use
#             model = "mistral-small-latest"
#
#             # Define the message with user query and the document URL
#             messages = [
#                 {
#                     "role": "user",
#                     "content": [
#                         {
#                             "type": "text",
#                             "text": '''Please extract the table from the given image, accurately recognize the text in table and return data in array of csv format '''
#                         },
#                         {
#                             "type": "image_url",
#                             "image_url": document_url  # Use the URL from the upload response
#                         }
#                     ]
#                 }
#             ]
#             chat_response = client.chat.complete(
#                 model=model,
#                 messages=messages
#             )
#             extracted_text = chat_response.choices[0].message.content
#             pattern = r"```csv\n([\s\S]*?)```"
#             match = re.search(pattern, extracted_text)
#             csv_data = match.group(1)
#
#             lines = csv_data.strip().split('\n')
#             rows = []
#             for line in lines:
#                 row = line.split(',')
#                 rows.append(row)
#             os.remove(pdf_file_path)
#             response = HttpResponse(content_type='text/csv')
#             response['Content-Disposition']= f'attachment; filename="{filename}_extracted_data.csv"'
#             writer= csv.writer(response)
#             writer.writerows(rows)
#             return response
#     return render(request, "table_extraction.html")
#
# def face_comparison(request):
#     if request.method=='POST' and request.FILES['org_image'] and request.FILES['team_image'] :
#         org_image= request.FILES['org_image']
#         team_image = request.FILES['team_image']
#         if org_image.name.lower().endswith(('.jpg', '.jpeg', '.png')) and team_image.name.lower().endswith(('.jpg', '.jpeg', '.png')):
#             fs=FileSystemStorage()
#             org_file_name=  fs.save(org_image.name,org_image)
#             org_file_path= fs.path(org_file_name)
#             team_file_name= fs.save(team_image.name, team_image)
#             team_file_path = fs.path(team_file_name)
#             distance ,  result = image_compare(org_file_path,team_file_path)
#             return render(request, 'face_comparison.html', context={'distance':distance, 'result':result ,'org_file_name': org_file_name ,'team_file_name':team_file_name })
#
#     return render(request,'face_comparison.html' )
#
#
# def image_compare(image_path_1, image_path_2):
#
# ## for the Deep Face
#     try:
#         result = DeepFace.verify(image_path_1, image_path_2)
#         return result['distance'], result['verified']
#     except Exception as error:
#         return 0 , error


from rest_framework import viewsets


from .models import Students, UserDetails
from .serializers import StudentsSerializer
import hashlib
import json

class StudentsViewSet(viewsets.ModelViewSet):
    queryset = Students.objects.all()
    serializer_class = StudentsSerializer

# class UserDetailsViewSet(viewsets.ModelViewSet):
#     queryset = UserDetails.objects.all()
#     serializer_class = UserDetailsSerializer


@api_view(["POST" ,"PATCH"])
def user_details(request):
    if request.method == "POST" :
        username= request.data["username"]
        password =  request.data["password"]
        phone = request.data ["phone"]
        user=  UserDetails.objects.get(username=username)
        if user :
            return JsonResponse({"error" : "Username is  exists" }, status = 400)
        try :
            user =  UserDetails(username=username, phone=phone)
            user.set_password(password)
            token = hashlib.sha256(username.encode()).hexdigest()
            user.token = token
            user.save()
            return JsonResponse({"message" : "User created Successfully"})
        except :
            return JsonResponse({"error" : "Unable to create the user"})
    return JsonResponse({"error" : "Internal server error"})

@api_view(['POST'])
def login_user(request):
    if request.method=='POST' :
        username= request.data["username"]
        password =  request.data["password"]
        if username == '' and password == '' :
            return JsonResponse({"error" : "Username and passwords are required"})
        try :
            user = UserDetails.objects.get(username=username)
            if user.check_password(password):
                
                return JsonResponse({"token ":user.token} , status = 200 )
            else:
                return JsonResponse({'error': "Username and password are not correct" }, status =401)
        except :
            return JsonResponse({"error" : "user not found"} ,status = 404)

    return JsonResponse({"error" : "Something went wrong"} , status= 500)

def send_email_view(request):
    subject = "Verification of User Account"
    message = "Thi is test mail"
    from_email = settings.EMAIL_HOST_USER
    recipient_list= ['dhanunjay.b@e-commsys.com.au']

    try :
        send_mail(subject,message,from_email,recipient_list)
        return HttpResponse("email send successfully")
    except Exception as e :
        return HttpResponse(f"Error in sending mail {str(e)}")









